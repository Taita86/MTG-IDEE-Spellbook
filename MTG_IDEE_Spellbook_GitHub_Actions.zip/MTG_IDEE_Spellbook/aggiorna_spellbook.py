#!/usr/bin/env python3
"""Scarica tutte le varianti pubbliche Commander Spellbook e costruisce SQLite + CSV + Excel.
Uso: python aggiorna_spellbook.py --out archivio_spellbook
Richiede: requests, openpyxl (solo per l'esportazione XLSX opzionale).
"""
import argparse,csv,datetime,hashlib,json,pathlib,sqlite3,time,urllib.parse
import requests

def textify(x):
 if x is None:return ''
 if isinstance(x,str):return x
 return json.dumps(x,ensure_ascii=False,separators=(',',':'))

def names(x):
 if not isinstance(x,list):return []
 out=[]
 for obj in x:
  if isinstance(obj,str):out.append(obj)
  elif isinstance(obj,dict):
   card=obj.get('card',obj)
   if isinstance(card,dict):out.append(card.get('name') or card.get('oracle_name') or str(card.get('id','')))
   else:out.append(str(card))
 return [x for x in out if x]

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',default='archivio_spellbook');p.add_argument('--limit',type=int,default=100);p.add_argument('--delay',type=float,default=.5);p.add_argument('--base',default='https://backend.commanderspellbook.com/variants/');a=p.parse_args()
 out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
 session=requests.Session();session.headers.update({'User-Agent':'MTG-IDEE-Archive/1.0 (research backup)','Accept':'application/json'})
 def get(url):
  for attempt in range(7):
   try:
    r=session.get(url,timeout=50)
    if r.status_code in (429,500,502,503,504):
     time.sleep(min(90,2**attempt));continue
    r.raise_for_status();return r.json()
   except requests.RequestException:
    if attempt==6:raise
    time.sleep(min(90,2**attempt))
  raise RuntimeError('API non disponibile')
 first=get(a.base+'?'+urllib.parse.urlencode({'limit':a.limit,'offset':0}))
 if not isinstance(first,dict) or 'results' not in first or 'count' not in first:raise RuntimeError('Formato API inatteso: nessun count/results')
 expected=int(first['count']); print('Varianti dichiarate:',expected,flush=True)
 db=sqlite3.connect(out/'spellbook.sqlite');db.execute('CREATE TABLE IF NOT EXISTS variants(id TEXT PRIMARY KEY, cards TEXT, prerequisites TEXT, mana_needed TEXT, steps TEXT, results TEXT, identity TEXT, url TEXT, raw_json TEXT NOT NULL)');db.execute('CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT)');db.execute('DELETE FROM variants');db.commit()
 offset=0;seen=set();next_url=a.base+'?'+urllib.parse.urlencode({'limit':a.limit,'offset':0})
 while next_url:
  data=first if offset==0 else get(next_url)
  records=data.get('results',[])
  if not records:break
  for v in records:
   ident=str(v.get('id',''))
   if not ident:raise RuntimeError('Variante senza ID')
   if ident in seen:raise RuntimeError('ID duplicato nella paginazione: '+ident)
   seen.add(ident)
   cards=names(v.get('uses') or v.get('cards') or [])
   db.execute('INSERT OR REPLACE INTO variants VALUES(?,?,?,?,?,?,?,?,?)',(ident,' | '.join(cards),textify(v.get('other_prerequisites') or v.get('prerequisites')),textify(v.get('mana_needed')),textify(v.get('description') or v.get('steps')),textify(v.get('produces') or v.get('results')),textify(v.get('identity') or v.get('color_identity')),f'https://commanderspellbook.com/combo/{ident}/',json.dumps(v,ensure_ascii=False)))
  db.commit();offset+=len(records)
  print(f'{offset}/{expected}',flush=True)
  nxt=data.get('next')
  if nxt:next_url=urllib.parse.urljoin(a.base,nxt)
  elif offset<expected:next_url=a.base+'?'+urllib.parse.urlencode({'limit':a.limit,'offset':offset})
  else:next_url=None
  if next_url:time.sleep(a.delay)
 if len(seen)!=expected:raise RuntimeError(f'INCOMPLETO: scaricati {len(seen)} di {expected}')
 db.execute('INSERT OR REPLACE INTO metadata VALUES(?,?)',('downloaded_utc',datetime.datetime.now(datetime.timezone.utc).isoformat()))
 db.execute('INSERT OR REPLACE INTO metadata VALUES(?,?)',('count',str(expected)))
 db.execute('INSERT OR REPLACE INTO metadata VALUES(?,?)',('source',a.base));db.commit()
 with (out/'varianti.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.writer(f);w.writerow(['id','cards','prerequisites','mana_needed','steps','results','identity','url'])
  for row in db.execute('SELECT id,cards,prerequisites,mana_needed,steps,results,identity,url FROM variants ORDER BY id'):w.writerow(row)
 try:
  from openpyxl import Workbook
  wb=Workbook();ws=wb.active;ws.title='Varianti';ws.append(['ID','Carte','Prerequisiti','Mana','Sequenza','Risultati','Colori','URL'])
  for row in db.execute('SELECT id,cards,prerequisites,mana_needed,steps,results,identity,url FROM variants ORDER BY id'):ws.append([str(x)[:32767] if x is not None else '' for x in row])
  ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
  wb.save(out/'spellbook.xlsx')
 except ImportError:print('openpyxl non installato: CSV e SQLite completati, Excel non creato')
 manifest={'status':'complete','count':expected,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':a.base,'sha256_db':hashlib.sha256((out/'spellbook.sqlite').read_bytes()).hexdigest()}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 print('ARCHIVIO COMPLETO:',out,expected)
 db.close()
if __name__=='__main__':main()
