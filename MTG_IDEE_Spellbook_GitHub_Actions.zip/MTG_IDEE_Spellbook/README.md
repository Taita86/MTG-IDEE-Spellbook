# MTG IDEE — Commander Spellbook Archive

Archivio indipendente, non affiliato a Commander Spellbook. Conserva i dati originali delle varianti pubbliche scaricate dalla API, con verifica del conteggio.

## GitHub Actions

1. Crea un repository GitHub e inserisci i file mantenendo `.github/workflows/sync-spellbook.yml`.
2. Apri **Actions → Aggiorna archivio Commander Spellbook → Run workflow**.
3. A esecuzione conclusa, scarica l'artifact `commander-spellbook-archive`.
4. Carica `spellbook.sqlite` tra i file del progetto MTG IDEE per consultazioni future.

La sincronizzazione si ripete ogni lunedì alle 05:17 UTC. Se l'API non è disponibile o il conteggio non torna, il workflow fallisce e **non** pubblica un archivio dichiarato completo.

## Output

- `spellbook.sqlite`: dati originali JSON e campi tabellari
- `spellbook.xlsx`: esportazione Excel
- `varianti.csv`: tabella CSV
- `manifest.json`: conteggio, data, SHA256

**Limiti:** la completezza si riferisce alle varianti esposte dall'endpoint al momento della sincronizzazione. Non equivale a verifica manuale delle regole di ogni combo. I campi strutturati possono evolvere con l'API; il JSON originale viene preservato.
